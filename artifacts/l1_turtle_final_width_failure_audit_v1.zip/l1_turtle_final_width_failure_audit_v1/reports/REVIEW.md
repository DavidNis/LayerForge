# Turtle retained-width failure audit

Status: `READY_FOR_USER_TEST`. L1 remains not approved.

## Mask polarity

- `retained_material_mask.png`: 255 is physical material; 0 is empty.
- `through_cutouts_mask.png`: exact inverse; 255 is empty through-cutout.
- The colored/black pixels in each physical preview coincide exactly with
  retained material. Near-white preview pixels are cutouts.
- Hidden retained material is included in the physical mask. No inversion was
  found in loading, validation, or preview generation.

There are two black sheets. Back-to-front sheet 2 is the visually solid plate
with only a few openings and it passes. Back-to-front sheet 9 has extensive
turtle, mountain, water, and leaf cutouts; its remaining black webs fail.

## Scale

The rejected run mapped the full 576-pixel mask to 200 mm, giving 0.347222
mm/pixel and a 177.778 mm artwork aperture. The confirmed 200 mm artwork scale
maps the 512-pixel aperture at 0.390625 mm/pixel and makes the existing appended
perimeter produce a 225 mm outer sheet. The current representation cannot make
both the aperture and outer sheet exactly 200 mm without changing the perimeter
mapping.

The native validator uses a 5x5 ellipse in both mappings. A 4x diagnostic of the
same unchanged rule uses 0.09765625 mm samples and a 13x13 ellipse, much closer
to the requested 1.2 mm threshold.

## Rejected-sheet results

| Back index | Color | Original/reproduced cores | Dominant neck location in 200 mm artwork | Visibility | 4x result | Assessment |
|---:|---|---:|---|---|---|---|
| 4 | `#90C6E1` | 45 / 45 | sun/snow junction, approximately (138.87, 42.19) mm | hidden | 39 cores | verified near-threshold bottleneck |
| 5 | `#5DA146` | 74 / 74 | lower turtle/leaf junction, approximately (86.52, 144.92) mm | hidden | 39 cores | verified near-threshold bottleneck |
| 6 | `#4B98CF` | 110 / 110 | same lower turtle/leaf junction | hidden | 351 cores | verified near-threshold bottleneck |
| 7 | `#276DA3` | 110 / 110 | same lower turtle/leaf junction | hidden | 351 cores | verified near-threshold bottleneck |
| 8 | `#986840` | 121 / 121 | same lower turtle/leaf junction | hidden | 351 cores | verified near-threshold bottleneck |
| 9 | `#0E0F0D` | 214 / 214 | same lower turtle/leaf junction | visible | 655 cores | verified near-threshold bottleneck |
| 10 | `#4B98CF` | 2 / 2 | two one/two-pixel water-edge remnants | visible | 0 cores, PASS | native-raster false positive |

Every failed native core connects at a 3x3 erosion footprint and disconnects at
5x5. At the intended artwork scale those native footprints correspond to 1.172
mm and 1.953 mm; native sampling is too coarse for an exact width. The 4x audit
resolves sheets 4-9 more closely: their cores connect at 11 samples (1.074 mm)
and disconnect at 13 samples (1.270 mm). The best discrete estimate is therefore
about 1.172 mm with approximately +/-0.098 mm sampling uncertainty. This is
consistent with genuine geometry just below 1.2 mm. Sheet 10 passes at 13
samples and must not be rejected solely from the native 5x5 result.

All twelve physical masks are one 4-neighbor component. The failures are not
floating pieces, mask inversion, narrow cutouts, or broken perimeter anchoring.
They are erosion-disconnected retained cores, except for sheet 10's coarse-raster
false positive. On sheets 5-9 the dominant 612-pixel native orphan is a
substantial region attached through the highlighted narrow web. No alternative
path survives the accurate 1.2 mm diagnostic. Sheet 4's dominant 40-pixel core
is smaller but uses the same sub-threshold attachment mechanism.

## Validator assessment

The validator interprets retained material, cutouts, hidden material, and the
shared perimeter correctly. Its native odd-kernel rounding is too coarse to
justify every rejection: it creates the sheet-10 false positive and reports a
5-pixel footprint much larger than 1.2 mm in either physical mapping. The 4x
check nevertheless confirms real near-threshold bottlenecks on sheets 4-9.

Recommended correction: retain the 1.2 mm rule but perform width-qualified
connectivity on a physically calibrated supersampled or vector mask, so the
erosion footprint approximates 1.2 mm without native odd-kernel over-rounding.
Reclassify geometry before feeding failures back to the planner.
